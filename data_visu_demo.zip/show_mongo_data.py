from pymongo import MongoClient
import os

# 设置 MongoDB 连接
username = os.getenv("MONGO_USERNAME", "root")
password = os.getenv("MONGO_PASSWORD", "password123")
host = os.getenv("MONGO_HOST", "192.168.100.120")
port = int(os.getenv("MONGO_PORT", 27017))
myclient = MongoClient(f'mongodb://{username}:{password}@{host}:{port}/')
db = myclient[os.getenv("MONGO_DB", "cup_fox_movie")]
collection = db[os.getenv("MONGO_TABLE", "movie_data")]


# 获取所有电影数据
def get_all_movie_data():
    return list(collection.find())


# 电影网站更新时间分布
def get_movie_date():
    """
    return: list
    """
    data_list = []
    # 查询更新时间字段，避免返回'_id'字段
    update_time = collection.find({}, {'更新时间': 1, '_id': 0})

    # 提取所有更新时间
    for i in update_time:
        data_list.append(i['更新时间'].split("-")[1])  # 获取月份数据
        # print(i)
    return data_list


# 导演参影
def get_movie_daoyan():
    """
    return: list
    """
    daoyan_data_list = []
    daoyan_name = collection.find({}, {'导演': 1, '_id': 0})
    for x in daoyan_name:
        # print(x["导演"])
        for y in x["导演"]:
            daoyan_data_list.append(y)

    return daoyan_data_list


# 演员
def get_movie_yanyuan():
    """
    return: list
    """
    yanyuan_data_list = []
    yanyuan_name = collection.find({}, {'演员': 1, '_id': 0})
    for x in yanyuan_name:
        # print(x["演员"])
        for y in x["演员"]:
            yanyuan_data_list.append(y)

    return yanyuan_data_list


# 影片类型占比分布
def get_movie_type():
    """
    return: list
    """
    type_data_list = []
    type_name = collection.find({}, {'类型': 1, '_id': 0})
    for x in type_name:
        # print(x["类型"])
        for y in x["类型"]:
            type_data_list.append(y)

    return type_data_list


# 网友评论 整体拼接成字符串
def get_movie_remark():
    """
    return: string
    """
    remarks = ""
    remark_name = collection.find({})

    for x in remark_name:

        remark_sources = [
            x.get("【星辰影院】网友评价", ""),
            # x.get("【电影天堂】网友评价", ""),
            # x.get("【搜狐视频】网友评价", ""),
            # x.get("【爱看影视】网友评价", ""),
            # x.get("【星空电影网】网友评价", ""),
            # x.get("【芒果TV】网友评价", ""),
            # x.get("【咪咕影院】网友评价", "")
        ]

        for remark in remark_sources:
            if remark:
                remarks += remark

    return remarks


def get_movie_miaoshu():
    """
    return: string
    """
    str_sum = ""
    miaoshu_name = collection.find({}, {'影片描述': 1, '_id': 0})
    for x in miaoshu_name:
        # print(x["影片描述"])
        str_sum += x["影片描述"]

    return str_sum


# 影片地区与发布年份数据
def get_movie_label():
    """
    return: dict
    """
    label_data_list_year = []
    label_data_list_guoji = []
    label_dict = {}
    label_name = collection.find({}, {'标签': 1, '_id': 0})
    for x in label_name:
        if len(x["标签"][0]) == 4:
            label_data_list_year.append(x["标签"][0])
            label_data_list_guoji.append(x["标签"][1])

    label_dict["年份"] = label_data_list_year
    label_dict["国家"] = label_data_list_guoji

    return label_dict


if __name__ == '__main__':
    print(get_movie_date())
