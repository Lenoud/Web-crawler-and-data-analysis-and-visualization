from flask import Flask, render_template
import keshihua as k

app = Flask(__name__)


@app.route('/')
def index():
    world_map_chart = k.world_map().render_embed()
    movie_type_chart = k.movie_type_image().render_embed()
    movie_update_chart = k.movie_update().render_embed()
    wordcloud_chart = k.word_cloud().render_embed()
    daoyan_num_chart = k.daoyan_num().render_embed()

    return render_template("index.html",
                           world_map=world_map_chart,
                           movie_type=movie_type_chart,
                           movie_update=movie_update_chart,
                           wordcloud=wordcloud_chart,
                           daoyan_num=daoyan_num_chart)


if __name__ == '__main__':
    # 监听所有IP地址
    app.run(debug=True, host='0.0.0.0', port=5000)
