from pyecharts.charts import Pie, Map, Line, Bar, WordCloud
from pyecharts.options import InitOpts, LabelOpts, VisualMapOpts, TitleOpts, LegendOpts, ToolboxOpts
from pyecharts import options as opts
import show_mongo_data
from collections import Counter
import pandas as pd
import jieba
import re
import name_map


# <!-- 世界地图 -->
def world_map():
    guojia = show_mongo_data.get_movie_label()["国家"]
    city_data = [1] * len(show_mongo_data.get_movie_label()["国家"])

    map0 = (Map(init_opts=InitOpts(width="1350px", height="400px", bg_color=None))
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
        .add(
        series_name="影片数量",
        data_pair=[(i, j) for i, j in zip(guojia, city_data)],
        maptype="world",
        is_map_symbol_show=False,
        name_map=name_map.name_map_value(),
        label_opts=LabelOpts(is_show=False))
        .set_global_opts(
        title_opts=opts.TitleOpts(title="影片国家分布图", title_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE")),
        legend_opts=opts.LegendOpts(is_show=False),
        visualmap_opts=VisualMapOpts(
            min_=0, max_=200, is_calculable=True,
            range_color=["#f5b7b1", "#e74c3c", "#c0392b", "#8e44ad", "#2980b9", "#1abc9c"],
            is_show=False))
    )
    return map0


# <!-- 柱状图 -->
def daoyan_num():
    directors = show_mongo_data.get_movie_daoyan()
    directors = [i for i in directors if len(i) > 0]
    director_count = pd.Series(directors).value_counts().head(10)

    bar = (Bar(init_opts=InitOpts(width="400px", height="400px", bg_color=None))
        .add_xaxis(director_count.index.tolist())
        .add_yaxis("", director_count.values.tolist())
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
        .set_global_opts(
        title_opts=opts.TitleOpts(title="导演参与影片数量Top10",
                                  title_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE"), ),
        xaxis_opts=opts.AxisOpts(name="导演", axislabel_opts=opts.LabelOpts(rotate=45, color="#EEEEEE"),
                                 name_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE")),
        yaxis_opts=opts.AxisOpts(name="影片数量",
                                 name_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE"),
                                 axislabel_opts=opts.LabelOpts(color="EEEEEE"), ),
        toolbox_opts=opts.ToolboxOpts(is_show=False),
    ))

    return bar


# <!-- 饼图 -->
def movie_type_image():
    film_types = show_mongo_data.get_movie_type()
    film_type_counts = pd.Series(film_types).value_counts().head(10)
    data = [(index, count) for index, count in film_type_counts.items()]

    pie_chart = (Pie(init_opts=InitOpts(width="800px", height="600px", bg_color=None))
        .add("", data)
        .set_series_opts(label_opts=LabelOpts(formatter="{b}: {d}%"))
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
        .set_global_opts(
        title_opts=TitleOpts(title="影片类型分布TOP10",
                             title_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE")),
        legend_opts=LegendOpts(is_show=True, orient="vertical", pos_left="left", pos_top="25px",
                               textstyle_opts=opts.TextStyleOpts(color="#EEEEEE"))
    ))
    return pie_chart


# <!-- 词云图 -->
def word_cloud():
    reviews = jieba.lcut(show_mongo_data.get_movie_remark())
    word_counts = Counter(reviews)

    word_data = [(word, count) for word, count in word_counts.items() if
                 len(word) > 1 and not re.match(r'^[a-zA-Z0-9]+$', word)]
    word_data = [(word, count) for word, count in word_data if count > 5]
    word_data = sorted(word_data, key=lambda x: x[1], reverse=True)[:500]

    wordcloud = (WordCloud(init_opts=InitOpts(width="950px", height="600px", bg_color=None))
                 .add("用户评价关键词分析", word_data, word_size_range=[20, 100], shape="circle")
                 .set_global_opts(
        title_opts=opts.TitleOpts(title="用户评价关键词分析", title_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE")),
        legend_opts=opts.LegendOpts(is_show=False))
                 .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
                 )
    return wordcloud


# <!-- 折线图 -->
def movie_update():
    monther = dict(Counter(show_mongo_data.get_movie_date()))
    dates = [f"2024-{item}" for item in monther.keys()]
    yearly_counts = list(monther.values())

    line_chart = (Line(init_opts=InitOpts(width="1800px", height="400px", bg_color=None))
        .add_xaxis(dates)
        .add_yaxis("影片数量", yearly_counts,
                   markpoint_opts={"symbol": "pin"},
                   is_smooth=True,
                   linestyle_opts=opts.LineStyleOpts(color="orange", width=4))
        .set_series_opts(label_opts=opts.LabelOpts(is_show=False))
        .set_global_opts(
        title_opts=TitleOpts(title="电影网站影片更新时间分布",
                             title_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE")),
        xaxis_opts=opts.AxisOpts(name="更新时间",
                                 axislabel_opts=opts.LabelOpts(color="#EEEEEE"),
                                 name_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE")),
        yaxis_opts=opts.AxisOpts(name="影片数量",
                                 axislabel_opts=opts.LabelOpts(color="#EEEEEE"),
                                 name_textstyle_opts=opts.TextStyleOpts(color="#EEEEEE")),

        legend_opts=opts.LegendOpts(is_show=False),

    )
    )

    return line_chart
