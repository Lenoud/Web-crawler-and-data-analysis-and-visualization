# -*- coding: utf-8 -*-
import os
from pymongo import MongoClient


class sava_db():
    def __init__(self):
        # 从环境变量中读取配置信息，若未设置则使用默认值
        self.username = os.getenv("MONGO_USERNAME", "root")  # 默认用户名为 root
        self.password = os.getenv("MONGO_PASSWORD", "password123")  # 默认密码为 password123
        self.host = os.getenv("MONGO_HOST", "192.168.100.120")  # 默认主机为 192.168.100.120
        self.port = int(os.getenv("MONGO_PORT", 27017))  # 默认端口为 27017
        self.db = os.getenv("MONGO_DB", "cup_fox_movie")  # 默认数据库为 cup_fox_movie
        self.table = os.getenv("MONGO_TABLE", "movie_data")  # 默认表为 movie_data

    def save_more_data(self, json_list):
        json_list_data = json_list
        myclient = MongoClient(f'mongodb://{self.username}:{self.password}@{self.host}:{self.port}/')  # MongoDB连接字符串
        mydb = myclient[self.db]  # 选中或者创建库
        mycol = mydb[self.table]  # 选中或者创建表
        mydict = json_list_data
        controller_more = mycol.insert_many(mydict)  # 插入多条数据
        return controller_more

    def save_one_data(self, json):
        json_data = json
        myclient = MongoClient(f'mongodb://{self.username}:{self.password}@{self.host}:{self.port}/')  # MongoDB连接字符串
        mydb = myclient[self.db]  # 选中或者创建库
        mycol = mydb[self.table]  # 选中或者创建表
        mydict = json_data
        controller_one = mycol.insert_one(mydict)  # 插入单条数据
        return controller_one
