import requests
from bs4 import BeautifulSoup
import re
import time
import random
import json


class data_get():

    def __init__(self):
        self.headers = {
            "accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
            "accept-language": "zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6",
            "cache-control": "no-cache",
            "pragma": "no-cache",
            "priority": "u=0, i",
            "sec-ch-ua": "\"Chromium\";v=\"130\", \"Microsoft Edge\";v=\"130\", \"Not?A_Brand\";v=\"99\"",
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": "\"Windows\"",
            "sec-fetch-dest": "document",
            "sec-fetch-mode": "navigate",
            "sec-fetch-site": "none",
            "sec-fetch-user": "?1",
            "upgrade-insecure-requests": "1",
            "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0"
        }
        self.headurl = f"https://cup-fox.com"

    def url_get(self,begin_page=1,end_page=3):
        """
        保存所有的url数据到data_type列表中，返回给video_data_get方法
        return: data_type=list
        """

        self.url_path = []  # 初始化列表，将所有url保存到其中


        for i in range(begin_page, end_page):

            index = i  # 页面数

            # 将页面数传入url中
            url = self.headurl + f"/cupfoxshow/dianying--------{index}---.html"

            try:
                data = requests.get(url, headers=self.headers)

                # 解析页面内容
                soup = BeautifulSoup(data.text, 'html.parser')

                # 查找所有的 a 标签
                elements = soup.find_all('a')

                # 输出每个元素的 href 属性
                for element in elements:
                    href = element.get('href')
                    if href and '/cupfox/' in href:
                        self.url_path.append(self.headurl + href)  # 将符合要求的path保存

                print(f"page {i} url add to list succeed")

                time.sleep(random.randint(1, 2))


            except Exception as e:
                print("出现异常:", e)

            # print(self.url_path) #打印出列表中的所有数据

        return self.url_path

    def video_data_get(self):
        """
        将json数据保存到一个列表中，将单引号清洗后，将结果返回
        return: list
        """
        url_list = self.url_path
        #url_list = ['https://cup-fox.com/cupfox/62448.html']  # 单个调试
        n=0
        dict_list = []
        for url in url_list:
            movie_info = {}  # 初始化字典

            try:
                data = requests.get(url, headers=self.headers)
                time.sleep(random.randint(1, 2))

                # 解析页面内容
                soup = BeautifulSoup(data.text, 'html.parser')

                '''电影信息提取'''
                element_info = soup.select(
                    'body > div.details > div.container.flex > div.mobile-main.mobile-main-type > div.movie.bj.br.card.border-shadow > div.cf.b-t')

                tree2 = element_info[0]

                ##格式化数据输出
                # print(tree2.prettify())

                # 提取电影信息
                movie_info['名称'] = tree2.find('h1').get_text()
                movie_info['图片'] = tree2.find('img').get("src")
                movie_info['别名'] = tree2.find('p', class_='cr3').get_text(strip=True).replace("别名：", '').split(",")
                movie_info['标签'] = [a.get_text() for a in
                                    tree2.select('.scroll-content')[0].find_all('a', target="_blank")]
                movie_info['连载'] = tree2.find('p', class_='cr3').find_next('p').get_text(strip=True).replace("连载：", "")
                movie_info['导演'] = [a.get_text() for a in
                                    tree2.find('p', class_='cr3').find_next('p').find_next('p').find_all("a",
                                                                                                         target="_blank")]
                movie_info['演员'] = [a.get_text() for a in tree2.find_all('p', class_='cr3 starLink')[0].find_all('a')]
                movie_info['类型'] = [a.get_text() for a in
                                    tree2.find('p', class_='cr3 starLink').find_next("p").find_all('a')]
                movie_info['分类'] = tree2.find('p', class_='cr3 starLink').find_next("p").find_next("p").get_text(
                    strip=True).replace("分类：", "")
                movie_info['更新时间'] = tree2.find('p', class_='cr3 starLink').find_next("p").find_next("p").find_next(
                    "p").get_text(strip=True).replace("更新时间：", "")

                # 单独提取出影片描述
                miaoshu = soup.select(
                    "body > div.details > div.container.flex > div.mobile-main.mobile-main-type > div.movie.bj.br.card.border-shadow > div.summary.detailsTxt")

                b_cleaned = re.sub(r'\s+', ' ', miaoshu[0].get_text(strip=True))
                movie_info['影片描述'] = b_cleaned.replace('展开', '')

                # print(movie_info)

                # 断点
                # exit()



                '''网友评论提取'''
                element = soup.select(
                    'body > div.details > div.container.flex > div.mobile-main.mobile-main-type > div:nth-child(6) > ul')

                # 选择 ul/li/b 标签
                tree1 = element[0]
                # print("-" * 30)

                # 使用 find_all 查找所有 <b> 标签
                b_tags = tree1.find_all('b')
                p_tags = tree1.find_all('p')
                # 将每一对 <b> 和 <p> 标签的内容清洗后打包成字典

                for b, p in zip(b_tags, p_tags):
                    # 获取标签内容，清除多余空格和回车
                    b_cleaned = re.sub(r'\s+', ' ', b.get_text(strip=True))
                    p_cleaned = re.sub(r'\s+', ' ', p.get_text(strip=True))
                    # 打包成列表
                    movie_info[b_cleaned] = p_cleaned

                # # 打印提取的电影信息
                # for key, value in movie_info.items():
                #     print(f"{key}: {value}")


                # # 打印字典
                # print(movie_info)
                # print()


                # # 字典转化成json
                json_dict = json.dumps(movie_info, ensure_ascii=False)
                dict_list.append(eval(json_dict))
                n+=1
                print(f"{n}保存电影：",movie_info["名称"])
                # print("json：\n", json_dict)
                # print("-" * 50)
                return dict_list

            except Exception as e:
                print("出现异常:", e)
        return dict_list


if __name__ == "__main__":
    data_scraper = data_get()  # 创建 data_get 类的实例
    url_list = data_scraper.url_get()  # 调用 url_get 方法获取数据
    print(f"提取出: {len(url_list)}个url数据")

    # 电影数据提取方法
    video = data_scraper.video_data_get()
    print(video)


