# -*- coding: utf-8 -*-
import json
import data_save_mongo
import data_get
import csv

db_client = data_save_mongo.sava_db()  # 创建mongo客户端

data_scraper = data_get.data_get()  # 创建 data_get 类的实例
#for i in range(1, 101, 1):
for i in range(101, 103, 1):
    # 调用 url_get 方法获取一页网页数据
    url_list = data_scraper.url_get(begin_page=i, end_page=i + 1)

    # 保存url列表
    with open('urlList.csv', 'a', encoding='utf-8', newline='') as f:
        f_csv = csv.writer(f)
        for url in url_list:
            f_csv.writerow([url])
        print("url_list wirte to urlList.csv file")

    print(f"提取出: {len(url_list)}个url数据")

    # json数据
    json_list = data_scraper.video_data_get()  # 调用此方法，执行网页数据的爬取
    # print(json_list)

    # 将json写入文件
    with open('jsonData.json', 'a', encoding='utf-8') as file:
        json.dump(json_list, file, ensure_ascii=False, indent=2)

    # 提交json到MongoDB
    save = db_client.save_more_data(json_list=json_list)
    print("保存成功：", save)

print("程序结束")
