# 茶杯狐数据可视化

## 简介
本项目基于 Python 开发，使用 Flask 构建 Web 应用，并结合多个 Python 库和工具实现数据处理、分析和可视化等功能。系统使用 MongoDB 作为数据库，采用主从架构部署，所有服务容器化运行在 Docker 上，使用 Jenkins 进行持续集成与部署。

## 安装与配置

### 1.本项目分为两个模块，data_pull_demo为数据采集模块，Data_visualization_demo为可视化模块
- 每个模块下都附有requirements.txt 使用pip安装模块依赖的库即可
- 本项目存储使用了mongodb集群结构，但是非刚需，单节点mongodb也可以运行，注意修改数据采集模块中的data_save_mongo.py和show_mongo_data.py中的数据库信息即可。
- 自动化容器化部署为可以不实现，此部分为难点，且为运维部署部分，不涉及爬虫可视化。
- 如果数据采集模块你无法运行或者爬取较慢，模块中保存了jsonData.json文件为之前爬取的数据，可以自行插入mongodb，或者运行inset_json_data.py程序，插入到mongodb（简单点说就是帮你写好了将所有数据插入到mongodb数据库里面的脚本）
- 数据存入mongodb后就可以运行Data_visualization_demo中的app.py即可运行可视化。



## 技术栈

### 后端
- **解释器**: Python 3.8
- **Web 框架**: Flask 3.0.3
- **分词工具**: jieba 0.42.1
- **数据处理**: pandas 2.0.3
- **数据可视化**: pyecharts 2.0.6
- **HTML 解析**: beautifulsoup4 4.12.3
- **数据库客户端**: pymongo 4.10.1
- **HTTP 请求库**: Requests 2.32.3

### 容器化与部署
- **容器运行时**: Docker-ce 27.0.3
- **CI/CD 平台**: Jenkins 2.462.3
- **代码仓库**: Gitea 22.3.1

### 数据库
- **数据库**: MongoDB 7.0.12 (主从架构)

### 操作系统与 Web 服务器
- **操作系统**: Rocky Linux 9.4
- **Web 服务器**: Nginx 1.25
