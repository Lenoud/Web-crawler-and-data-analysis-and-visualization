import pymongo
import json

username = "root"
password = "password123"
host = "192.168.100.120"
port = 27017

client = pymongo.MongoClient(f'mongodb://{username}:{password}@{host}:{port}/')
db = client["cup_fox_movie"]
collection = db["movie_data"]

with open('movie_data.json', 'r', encoding='utf-8') as file:
    for line in file:
        if line.strip():
            try:
                obj = json.loads(line)

                if "_id" in obj and "$oid" in obj["_id"]:
                    obj["_id"] = obj["_id"]["$oid"]

                collection.insert_one(obj)

            except json.JSONDecodeError as e:
                print(f"JSON decode error: {e}")
            except pymongo.errors.PyMongoError as e:
                print(f"MongoDB insert error: {e}")

print("Data inserted successfully!")
